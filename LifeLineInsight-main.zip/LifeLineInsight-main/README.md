# data-analystics-project
"Predicting suicide rates in India (2012-2023) using Kaggle data (2001-2012) and linear regression analysis."
